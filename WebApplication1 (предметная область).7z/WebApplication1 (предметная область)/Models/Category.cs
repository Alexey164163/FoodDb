﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1__предметная_область_.Models
{
    public class Category
    {
        [Key]
        public int id { get; set; }
        public string? Title { get; set; }
        public string Description { get; set; }
        public string Rating { get; set; }
    }
}
