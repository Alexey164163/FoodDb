﻿namespace WebApplication1__предметная_область_.Data
{
    public class ApplicationDbContext
    {
    }
}
